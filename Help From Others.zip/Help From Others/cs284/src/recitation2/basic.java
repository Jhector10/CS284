package recitation2;

public class basic
	{
	public int i;
	public int j;
	
	public basic(int i, int j)
		{
		this.i = i;
		this.j = j;
		}
	
	public int add()
		{return i+j;}
	
	public int multiply()
		{return i*j;}
	
	public int divide()
		{return i/j;}
	
	}
