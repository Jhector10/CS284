package basics;

public class Apple extends Fruit {

	// data field
	private String type;
	
	public Apple(String color, int acitidy) {
		super(color, acitidy);
		// TODO Auto-generated constructor stub
	}
	
}
