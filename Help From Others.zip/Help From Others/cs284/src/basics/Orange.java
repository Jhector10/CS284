package basics;

public class Orange extends Fruit {
	// data fields 
	private int slices;
	
	public Orange(String color, int acitidy, int slices) {
		super(color, acitidy);
		this.slices=slices;
	}
	
}
