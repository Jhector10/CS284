package basics;

public interface Colorable {
	public String getColor();
}
